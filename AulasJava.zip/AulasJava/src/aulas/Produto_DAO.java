/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulas;

import dao.DAO_Abstract;

/**
 *
 * @author u71661414176
 */
public class Produto_DAO extends DAO_Abstract{

    @Override
    public void insert() {
        //implementarei depois
    }

    @Override
    public void update() {
        //implementarei depois 

    @Override
    public void delete() {
        //implementarei depois
    
}
